
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;

public class Receiver extends Thread{
	private Socket socket;
	private ServerData sd;
	
	
	public Receiver(Socket socket){
		 this.socket = socket;
		    System.out.println("server�ڑ�����܂��� "
		                       + socket.getRemoteSocketAddress());
	}
	
	public void run() {
	    try {
	    	BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
	        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
	        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
	        String line;
	      while (true) { 			//��ɗv���M�����󂯂���
	    	  line= in.readLine();	//�N���C�A���g����̗v���M��
	    	  if(line!=null){
	    	  /*//�m�F�p
		        System.out.println(socket.getRemoteSocketAddress()
		                           + " ��M: " + line);
		        out.println(line);
		        System.out.println(socket.getRemoteSocketAddress()
		                           + " ���M: " + line);
		        */
		        
		        sd=new ServerData();
		        String str1=null,str2=null;
		        boolean flag=true;
				switch (line){		//�N���C�A���g����̗v���M�����󂯂ē��삷��
				case "a": //sign up		
					str1=in.readLine();str2=in.readLine();
					if(sd.checkLength(str1, str2)){
						flag=sd.makeUser(str1, str2);
					}
					if(flag){
						out.println("accept");
					}else{
						out.println("reject");
					}
					break;
					
				case "b": //sign in
					str1=in.readLine();str2=in.readLine();
					System.out.println(str1+str2);
					if(sd.queryUser(str1, str2)){
						out.println("accept");
					}else{
						out.println("reject");
					}
					break;
				case "c": //save data
					str1=in.readLine();//str2=in.readLine();
					Object saveobj =ois.readObject();
					
					if(sd.saveData(str1, saveobj)){
						out.println("accept");
					}else{
						out.println("reject");
					}
					break;
				case "d": //load data
					str1=in.readLine();
					Object loadobj=sd.loadData(str1);
					oos.writeObject(loadobj);
					break;
				case "e": //disconnect
					out.println("accept");
					in.close();out.close();
					oos.close();ois.close();
					socket.close();
				
				default:  ;
				}
			}
	      
	     }
	      
	    } catch (IOException e) {
	      e.printStackTrace();
	    } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
	      try {
	        if (socket != null) {
	          socket.close();
	        }
	      } catch (IOException e) {}
	      System.out.println("�ؒf����܂��� "
	                         + socket.getRemoteSocketAddress());
	    }
	  }	
	
	
		
}
